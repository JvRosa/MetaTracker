//Aplica o scroll com o mouse na horizontal na parte principal
const elementoARolar = document.querySelector(".Principal");
let estaPressionado = false;
let inicioX;
let inicioScrollLeft;

elementoARolar.addEventListener('mousedown', (e) => {
    estaPressionado = true;
    inicioX = e.clientX;
    inicioScrollLeft = elementoARolar.scrollLeft;
});

document.addEventListener('mouseup', () => {
    estaPressionado = false;
});

document.addEventListener('mousemove', (e) => {
    if (!estaPressionado) return;

    const deltaX = e.clientX - inicioX;
    elementoARolar.scrollLeft = inicioScrollLeft - deltaX;
});

elementoARolar.addEventListener('mouseenter', () => {
    elementoARolar.style.cursor = 'grabbing';
});

elementoARolar.addEventListener('mouseleave', () => {
    if (!estaPressionado) {
        elementoARolar.style.cursor = 'grab';
    }
});
//---------------------------------------------------------------------------------------------------


let vetCategorias = [];

const botaoAdicionarCategoria = document.querySelector(".adicionaCategoria");

const conteudoPrincipal = document.querySelector(".Principal");

botaoAdicionarCategoria.addEventListener("click", CriarNovaCategoria);

function CriarNovaCategoria() {

    let categoria = {
        id: vetCategorias.length,
        nome: "Nova categoria",
        cor: "#bbbbbb",
        metas: []
    }

    categoria.metas.push({
        idMeta: categoria.metas.length,
        texto: "Nova meta",
        concluida: false,
        dataConclusao: ""
    })

    vetCategorias.push(categoria);

    const novaCategoriaDiv = document.createElement("div");
    novaCategoriaDiv.className = "Categoria";

    novaCategoriaDiv.innerHTML = `
    <header class="CabecalhoCartao">
        <div class="CabecalhoCartaoParteSuperior">
            <h2 class="TituloCategoria">${categoria.nome}</h2>
            <div class="menuCategoria">
            <input type="color" class="inputCorDaCategoria" name="corDoCartao">
            <i class="fa-solid fa-trash categoria${vetCategorias.length} excluirCategoria"></i>
            <i class="fa-solid fa-pen editarTituloCartao"></i>
            </div>
        </div>
        <div class="CabecalhoCartaoParteInferior">
            <i class="fa-solid fa-list-ol"></i>
            <p>${categoria.metas.length} metas</p>
        </div>
    </header>
    <ul class="AreaMetas">
        <li class="meta">
            <div class="checkboxEMeta">
                <input type="checkbox" id="${categoria.nome}Meta${categoria.metas[0].idMeta}" class="checkbox-escondido">
                <label for="${categoria.nome}Meta${categoria.metas[0].idMeta}" class="checkbox-personalizado"></label>
                <p class="tituloTarefa">${categoria.metas[0].texto}</p>
            </div>
            <div class="EditarEApagar">
                <i class="fa-solid fa-pen editarMeta"></i>
                <i class="fa-solid fa-trash excluirMeta"></i>
            </div>
        </li>

        <li  class="adicionarMeta">
            <i class="fa-solid fa-plus"></i>
        </li>
    </ul>
`;


    const botaoAdicionarCategoria = document.querySelector(".AdicionarCategoria");

    conteudoPrincipal.insertBefore(novaCategoriaDiv, botaoAdicionarCategoria);

    const botaoEditarCategoria = document.querySelector(".editarTituloCartao");

    const botaoEditarMeta = document.querySelector(".editarMeta");

    botaoEditarMeta.addEventListener("click", editarMeta);

    botaoEditarCategoria.addEventListener("click", editarCategoria);

    const botaoExcluirCategoria = novaCategoriaDiv.querySelector(`.categoria${vetCategorias.length}`);

    botaoExcluirCategoria.addEventListener("click", excluirCategoria);

    const inputAlterarCorCategoria = document.querySelector(".inputCorDaCategoria");
    inputAlterarCorCategoria.value = vetCategorias[0].cor;
    mudarAparenciaDaCategoria();

    adicionarEventListenersEditarCategoria();
}

function adicionarEventListenersEditarCategoria() {
    const botoesEditarCategoria = document.querySelectorAll(".editarTituloCartao");
    
    botoesEditarCategoria.forEach(botao => {
        botao.addEventListener("click", editarCategoria);
    });
}


function editarCategoria(e) {

    const categoriaAtual = e.target.closest('.Categoria');
    const inputAlterarCorCategoria = categoriaAtual.querySelector(".inputCorDaCategoria");
    const botaoEditarCategoria = categoriaAtual.querySelector(".editarTituloCartao");
    const botaoExcluirCategoria = categoriaAtual.querySelector(".excluirCategoria");
    const tituloCategoria = categoriaAtual.querySelector(".TituloCategoria");

    if (botaoEditarCategoria.classList.contains("fa-pen")) {

        inputAlterarCorCategoria.style.display = "block";
        botaoExcluirCategoria.style.display = "block";
        botaoEditarCategoria.classList.remove("fa-pen");
        botaoEditarCategoria.classList.add("fa-check");

        const inputTitulo = document.createElement("input");
        inputTitulo.type = "text";
        inputTitulo.value = tituloCategoria.textContent;
        inputTitulo.className = "inputEditarTitulo";
        tituloCategoria.replaceWith(inputTitulo);
        inputTitulo.focus()

        //Alterar a forma que identifica o cartão aqui-----------------------------------------------------------
        inputAlterarCorCategoria.value = vetCategorias[0].cor;
        mudarAparenciaDaCategoria();

        inputAlterarCorCategoria.addEventListener("input", mudarAparenciaDaCategoria);

    } else {

        const tituloCategoria = document.createElement("h2");
        tituloCategoria.classList.add("TituloCategoria");
        const inputEditarTitulo = document.querySelector(".inputEditarTitulo");
        //Alterar depois a maneira como está encontrando o objeto para alterar o valor-------------------------
        vetCategorias[0].nome = inputEditarTitulo.value;
        tituloCategoria.textContent = vetCategorias[0].nome;
        inputEditarTitulo.replaceWith(tituloCategoria);

        inputAlterarCorCategoria.style.display = "none";
        botaoExcluirCategoria.style.display = "none";
        botaoEditarCategoria.classList.remove("fa-check");
        botaoEditarCategoria.classList.add("fa-pen");

    }


}
adicionarEventListenersEditarCategoria();

function mudarAparenciaDaCategoria() {

    const inputAlterarCorCategoria = document.querySelector(".inputCorDaCategoria");
    const botaoEditarCategoria = document.querySelector(".editarTituloCartao");
    const botaoExcluirCategoria = document.querySelector(".excluirCategoria");
    const cabecalhoCategoria = document.querySelector(".CabecalhoCartao");
    const checkbox = document.querySelector(".checkbox-personalizado");
    const botaoAdicionaMeta = document.querySelector(".adicionarMeta");
    const botaoExcluirMeta = document.querySelector(".excluirMeta");
    const botaoEditarMeta = document.querySelector(".editarMeta");
    const categoria = document.querySelector(".Categoria");
    const meta = document.querySelector(".meta");


    var corDoInputCategoria = inputAlterarCorCategoria.value;


    //Mudar como busca o objeto nessa parte---------------------------------------------------------------------
    vetCategorias[0].cor = inputAlterarCorCategoria.value;

    //Mudança de valor de hexadecimal para RGB
    corDoInputCategoria = corDoInputCategoria.replace(/^#/, '');
    var bigint = parseInt(corDoInputCategoria, 16);

    var red = (bigint >> 16) & 255;
    var green = (bigint >> 8) & 255;
    var blue = bigint & 255;

    //Começa a alterar os backgrounds e cores do cartão
    //Alterações fixas, elas que definem como as proximas vao fazer o contraste
    categoria.style.backgroundColor = `rgba(${red},${green},${blue})`;
    categoria.style.boxShadow = `-2px 2px 4px rgb(${red}, ${green}, ${blue})`;
    cabecalhoCategoria.style.backgroundImage = `linear-gradient(rgb(${red + 160},${green + 160},${blue + 160}), rgb(${red},${green},${blue}))`;

    botaoEditarCategoria.style.backgroundColor = `rgb(${red},${green},${blue})`;
    botaoExcluirCategoria.style.backgroundColor = `rgb(${red},${green},${blue})`;
    botaoAdicionaMeta.style.backgroundColor = `rgb(${red + 50},${green + 50},${blue + 50})`;

    if (red < 127 && green < 127 && blue < 127) {//Escuro
        categoria.style.color = `white`;
        checkbox.style.border = `2px solid white`;
        checkbox.style.backgroundColor = `rgb(${red + 120},${green + 120},${blue + 120}`;
        meta.style.backgroundColor = `rgb(${red + 60},${green + 60},${blue + 60})`;
        meta.style.color = `white`;
        botaoEditarMeta.style.color = `white`;
        botaoExcluirMeta.style.color = `white`;
        botaoEditarMeta.style.backgroundColor = `rgb(${red + 50},${green + 50},${blue + 50})`;
        botaoExcluirMeta.style.backgroundColor = `rgb(${red + 50},${green + 50},${blue + 50})`;
    }
    else {//Claro
        categoria.style.color = `black`;
        checkbox.style.border = `2px solid black`;
        checkbox.style.backgroundColor = `rgb(${red},${green},${blue}`;
        meta.style.backgroundColor = `rgb(${red - 30},${green - 30},${blue - 30})`;
        meta.style.color = `black`;
        botaoEditarMeta.style.color = `black`;
        botaoExcluirMeta.style.color = `black`;
        botaoEditarMeta.style.backgroundColor = `rgb(${red},${green},${blue})`;
        botaoExcluirMeta.style.backgroundColor = `rgb(${red},${green},${blue})`;
    }

}


function editarMeta() {

    const botaoEditarMeta = document.querySelector(".editarMeta");
    const nomeMeta = document.querySelector(".tituloTarefa");

    if (botaoEditarMeta.classList.contains("fa-pen")) {

        const inputNomeMeta = document.createElement("input");
        inputNomeMeta.type = "text";
        inputNomeMeta.value = nomeMeta.textContent;
        inputNomeMeta.className = "inputEditarMeta";
        nomeMeta.replaceWith(inputNomeMeta);
        inputNomeMeta.focus()

        botaoEditarMeta.classList.remove("fa-pen");
        botaoEditarMeta.classList.add("fa-check");
    } else {

        const tituloMeta = document.createElement("p");
        tituloMeta.classList.add("tituloTarefa");
        const inputEditarMeta = document.querySelector(".inputEditarMeta");
        // Alterar depois a maneira como está encontrando o objeto para alterar o valor-----------------------------------------
        vetCategorias[0].metas[0].texto = inputEditarMeta.value;
        tituloMeta.textContent = vetCategorias[0].metas[0].texto;
        inputEditarMeta.replaceWith(tituloMeta);


        botaoEditarMeta.classList.remove("fa-check");
        botaoEditarMeta.classList.add("fa-pen");
    }
}


function excluirCategoria(botaoExcluirCategoria) {
    

    console.log(botaoExcluirCategoria);
}